# Grid Gallery

A Pen created on CodePen.io. Original URL: [https://codepen.io/mariacheline/pen/BKGNLz](https://codepen.io/mariacheline/pen/BKGNLz).

Practicing flexbox